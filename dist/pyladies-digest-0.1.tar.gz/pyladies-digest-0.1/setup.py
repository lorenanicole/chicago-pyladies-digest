from setuptools import setup, find_packages
import os

def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()

setup(
    name="pyladies-digest",
    version="0.1",
    author="Lorena Mesa",
    author_email="me@lorenamesa.com",
    description=("Command line tool to create a MailChimp template for PyLadies chapters"),
    license="BSD",
    keywords="pyladies email digest mailchimp",
    url="https://github.com/lorenanicole/chicago-pyladies-digest",
    packages=['data', 'digest'],
    long_description=read('README.md'),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Topic :: PyLadies Open Source Tool",
        "License :: OSI Approved :: BSD License",
    ],
)